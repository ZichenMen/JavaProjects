public class Triangle extends AbstractShape{
    private Point myP1;
    private Point myP2;
    private Point myP3;
    public Triangle(){ // The constructor that has no parameter passed in
        this.myP1 = new Point(0, 0);
        this.myP2 = new Point(1, 1);
        this.myP3 = new Point(2, 2);
    }

    public Triangle(final Point x, final Point y, final Point z){ // The constructor that allows user to accept parameters
        this.myP1 = x;
        this.myP2 = y;
        this.myP3 = z;
    }


    public String toString() {
        String type = "{Type=" + this.getType() + ", ";
        String point1 = String.format("Point1=[Point X=%d, Y=%d], ", myP1.getX(), myP1.getY());
        String point2 = String.format("Point2=[Point X=%d, Y=%d], ", myP2.getX(), myP2.getY());
        String point3 = String.format("Point3=[Point X=%d, Y=%d]}", myP3.getX(), myP3.getY());

        return type + point1 + point2 + point3 + "\n";
    }
    @Override
    public String getType() {
        return "Triangle";
    }

    @Override
    public double getPerimeter() { // Distance between two points (x1, y1) and (x2, y2) = √((x2 - x1)^2 + (y2 - y1)^2

        double mySide1 = Math.sqrt(Math.pow(myP2.getX() - myP1.getX(),2) + Math.pow(myP2.getY() - myP1.getY(),2));
        double mySide2 = Math.sqrt(Math.pow(myP3.getX() - myP2.getX(),2) + Math.pow(myP3.getY() - myP2.getY(),2));
        double mySide3 = Math.sqrt(Math.pow(myP3.getX() - myP1.getX(),2) + Math.pow(myP3.getY() - myP1.getY(),2));
        return mySide1 + mySide2 + mySide3;
    }

    @Override
    public double getArea() { // Calculate the area
        // Calculate the semi-perimeter (s): s = (a + b + c) / 2
        double s = this.getPerimeter() / 2;
        // Calculate the area using Heron's formula:
        // Area = √(s * (s - a) * (s - b) * (s - c))
        double mySide1 = Math.sqrt(Math.pow(myP2.getX() - myP1.getX(),2) + Math.pow(myP2.getY() - myP1.getY(),2));
        double mySide2 = Math.sqrt(Math.pow(myP3.getX() - myP2.getX(),2) + Math.pow(myP3.getY() - myP2.getY(),2));
        double mySide3 = Math.sqrt(Math.pow(myP3.getX() - myP1.getX(),2) + Math.pow(myP3.getY() - myP1.getY(),2));
        return Math.sqrt(s * (s - mySide1) * (s - mySide2) * (s - mySide3));
    }
}
